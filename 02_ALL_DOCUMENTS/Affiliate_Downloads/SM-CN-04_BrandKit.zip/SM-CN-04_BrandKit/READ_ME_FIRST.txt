SUPERMIND · BRAND KIT FOR CREATOR NETWORK AFFILIATES · SM-CN-04

WHAT IS IN HERE
  Wordmark, transparent PNG, in Signal White, Functional Black and Crown Gold.
  Web sizes (640 px wide) in Signal White and Functional Black.

HOW TO USE THE WORDMARK
  Place it as supplied. Keep it level, unstretched, in its original colour.
  Minimum 160 px wide on screen.
  Leave clear space of at least half the mark's height on every side.
  Signal White goes on dark backgrounds. Functional Black goes on light ones.
  Crown Gold is for dark, premium moments.

WHERE IT CAN GO
  Your posts, Reels, TikToks, stories, thumbnails, newsletters and websites.

WHERE IT CANNOT GO
  Anything printed or made: merch, packaging, signage, stickers, embroidery.
  Ask in Help first. Print files are released separately.

TAG @supermindlab ON EVERYTHING. Questions: the Help channel at whop.com/supermind.
